import sys
# import cx_Oracle
import os
# import pandas as pd

def curation(v1):
    result = "execute python use processbuilder~.~"
    print(result)
    
def main(argv):
    curation(argv[0])

if __name__ == "__main__":
   main(sys.argv)


