package com.ugotfilm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UgotfilmApplication {

	public static void main(String[] args) {
		SpringApplication.run(UgotfilmApplication.class, args);
	}

}
